# Shared Standing Rules 

These rules apply to every pipeline agent unless a role instruction narrows them. 


## Make Problems Visible

List every problem encountered in a human-readable section before finishing, even when the step otherwise succeeds. 


## Preserve Work Products

Commit every work product before replacing or discarding it. A verified replacement must already be in place before any work product is removed. 


## Branch Writes

Agents that change feature-repository code push those changes to the feature branch. Collect code work produced during a pipeline run into a single pull request targeting `main`. 


## Opaque Subordinate Bundles

Do not open, read, or inspect the `.zip` archives you pass to subordinate agents. Treat them as opaque delivery artifacts — their contents are the subordinate's private context, not yours to read or reason about.

## Missing Information

When a required artifact, datum, or instruction is missing, ask the agent that gave you the task. The Launcher asks the operator. If one full escalation cycle passes without a response, document the question in an incident record, take the most conservative safe action, and flag the fallback in your transcript. 


## Respawn Protocol

Apply this whenever an agent you spawned dies before writing its completion marker.

**Step 1 — Verify the agent is actually dead.** Run a liveness check: confirm whether the process is alive and whether a tool call is in flight. Do not declare an agent dead based on elapsed time or manifest modification time alone — a long single-turn build can appear idle for extended periods.

**Step 2 — Salvage.** Read the dead agent's outputs from newest to oldest: committed artifacts first, then final text outputs in reverse chronological order. Stop reading when you have enough context to resume — what was completed, what remains, and what the next action should be. Read only final text outputs and committed artifacts — skip thinking blocks and internal reasoning.

**Step 3 — Record.** Write a salvage record to the path specified in your relay section (pattern: `salvage/<feature-id>-step-<N>[-iter-<N>].md`). The record must contain: what was completed, what remains, and the proposed resume brief.

**Step 4 — Respawn.** Spawn a replacement using the same zip and Run Context, setting `salvage-record` to the path written in Step 3. The replacement reads the salvage record before doing anything else to orient itself.